db.stocks.find({}).limit(10)




db.people.distinct(
  "classification.sector"
  // : ObjectId("5a95f88e4b54b30c745cc713")}, 
  //{ "first_name":1, "_id":1, "address":1
  )




db.stocks.distinct({
  "classification.sector":1}
  )  

  
  db.stocks.find({
  "classification.sector" : "Information Technology"},
  {"symbol":1, "name":1,"classification.sector":1}
    )
   
  
  