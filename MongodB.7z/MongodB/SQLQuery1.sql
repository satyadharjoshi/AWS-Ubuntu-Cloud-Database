exec msdb.dbo.rds_restore_database

        @restore_db_name='WideWorldImporters',

		

		  @s3_arn_to_restore_from='arn:aws:s3:::joshibucketrds/WideWorldImporters-Full.bak';

        @s3_arn_to_restore_from='https://s3-us-west-2.amazonaws.com/joshibucketrds/WideWorldImporters-Full.bak';


		https://s3-us-west-2.amazonaws.com/joshibucketrds/WideWorldImporters-Full.bak
		
		exec msdb.dbo.rds_task_status @db_name='WideWorldImporters';


 