exec msdb.dbo.rds_restore_database

        @restore_db_name='FinalExam',

        @s3_arn_to_restore_from='https://s3-us-west-2.amazonaws.com/joshibucketrds/FinalExam.bak';


		exec msdb.dbo.rds_task_status @db_name='FinalExam';


 