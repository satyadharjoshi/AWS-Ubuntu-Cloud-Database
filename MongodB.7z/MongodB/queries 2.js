db.people.find({"_id" : ObjectId("5a95f88e4b54b30c745cc713")}, { "first_name":1, "_id":1, "address.zip":1})


db.people.find({
  "_id" : ObjectId("5a95f88e4b54b30c745cc713")}, 
  { "first_name":1, "_id":1, "address":1
  })

  
db.people.find({
  "_id" : ObjectId("5a95f88e4b54b30c745cc713")}, 
  { 
    "first_name":1,
     "_id":1, 
    "courses_detail":1
  })
  